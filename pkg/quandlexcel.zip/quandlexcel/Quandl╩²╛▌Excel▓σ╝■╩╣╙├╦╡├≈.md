# Quandl数据Excel插件使用说明

## 一、下载插件

请下载Quandl数据 Excel插件，无须安装，请解压到任意文件夹中，此插件目前仅支持Office 2010以及以上版本，office 2007以及以下版本目前暂不支持。



## 二、插件的配置与使用

在解压后的文件夹中，应该有两个.xll文件，ClassLibrary7-AddIn.xll以及ClassLibrary7-AddIn64.xll文件，这两个文件分别对应32位的Excel与64位的Excel，使用哪个请用户自行判断。

每个.xll文件对应一个.config的配置文件，也就是ClassLibrary7-AddIn.xll.config和ClassLibrary7-AddIn64.xll.config，用文本编辑器打开后，我们可以看到如下xml配置：

```<?xml version="1.0" encoding="utf-8"?>`
`<configuration>`
  `<appSettings>`
    `<add key="certpath" value="C:\Cert\read.data.thunderdb.io.pfx" />`
    `<add key="keypassword" value="covenantsql" />`
    `<add key="url" value="https://e.morenodes.com:11108/v1/query" />`
    `<add key="database" value="057e55460f501ad071383c95f691293f2f0a7895988e22593669ceeb52a6452a" />`
  `</appSettings>`
```</configuration>`

其中有四个配置可能需要修改，分别是：

certpath、keypassword、url、database

certpath是证书的绝对路径，证书是一个.pfx文件，应该已经打包在压缩包内，或请咨询客服。这里我们需要将其的文件绝对路径修改为其存放的路径。

keypassword是.pfx证书生成时设置的密码，如果用户下载的是.pem和.key文件经由ssh工具进行合成成.pfx文件的，那请输入对应的密码，如果下载的已经是.pfx文件，那默认的密码是covenantsql，也就是默认值，不需要修改。

url是数据库的https访问地址，如果是使用Quandl数据库，这里不需要修改。

database是数据库的名称，如果是使用Quandl数据库，这里不需要修改。

修改好配置文件之后，请保存。

然后我们有两种办法使用此Excel插件：

### 一种办法是:

直接双击对应的32位或64位Excel的xll文件打开，

![1548571303067](C:\Users\Jeff\AppData\Local\Temp\1548571303067.png)

这里会跳出一个对话框，我们选择第一个，仅为本回话启用此加载项。

然后我们新建一个Excel表格，即可在Excel的上方选项卡中看到CovenantSQL，说明插件加载成功。



### 第二种办法：

打开Excel，然后依次选择 文件 — 选项 — 加载项，管理选择 Excel 加载项，点击转到 然后 浏览 选择 解压后的对应版本的.xll文件，然后确定，在选项卡中如果成功加载出CovenantSQL即为成功加载，如下图：

![1548600943975](C:\Users\Jeff\AppData\Local\Temp\1548600943975.png)







## 三、Quandl Excel插件的使用

我们选择CovenantSQL的选项卡可以看到只有一个选项，就是Quandl数据查询，点击Quandl数据查询，会弹出一个窗体如下图所示：

![1548571609792](C:\Users\Jeff\AppData\Local\Temp\1548571609792.png)



其中红色框住的列表部分是一级目录，下方则是所选项的具体描述

绿色按钮是通过选择的一级目录来查询二级目录。这里查询时间会随着所查询二级目录的大小以及用户自身的网络速度等因素而不同，可能查询时间会超过1分钟，请耐心等待。

黄色部分左边的列表是二级目录，右边的窗体则为列表项所选择的表的描述。

蓝色部分是导出数据的可选泽项，limit Number是一次导出的最多数据条数，默认为10000条，最大值可填写100000，offset Number是从数据库的第几条开始导出的意思，因为之前会限定条数，例如我们之前导出了10000条数据，但是明显数据还没有导出全部，我们可以使用此功能选择offset 10000来从第10000条开始导出（因为数据库的计数从0开始，所以前10000条为0-9999）

